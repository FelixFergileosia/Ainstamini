<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid">
        <ul class="navbar-nav me-2">
            <li class="nav-item">
                <img src="<?php echo e(asset('images/logo.png')); ?>" class="img-responsive" style="width:6vw" alt="">
            </li>
        </ul>

        <div class="d-flex justify-content-center" style="width:50vw">
            <form class="d-flex flex-fill me-2" action=""  role="search">
                <input class="form-control me-2 text-white" type="search" placeholder="Search" name="search" >
                <button class="btn btn-outline-secondary text-black" type="submit">Search</button>
            </form>
        </div>
        <div style="width:30vw" class="d-flex flex-row">
            <div class="justify-content-start">
                <a class="me-2" href="/"><img src="<?php echo e(asset('images/home_icon.png')); ?>" style="width:4.5vw" class="img-responsive" alt=""></a>
                <a class="me-2" href="/add-post"><img src="<?php echo e(asset('images/add_icon.png')); ?>" style="width:4.5vw" class="img-responsive" alt=""></a>
                <a class="me-2" href="/profile"><img src="<?php echo e(asset('images/user_icon.png')); ?>" style="width:4.5vw" class="img-responsive" alt=""></a>
            </div>
        </div>
        <a type="submit" href="/logout"><img src="<?php echo e(asset('images/logout_icon.png')); ?>" style="width:4.5vw" class="img-responsive" alt=""></a>
    </div>
</nav>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('base.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Programming\ainstamini_v1\resources\views/base/navbar.blade.php ENDPATH**/ ?>