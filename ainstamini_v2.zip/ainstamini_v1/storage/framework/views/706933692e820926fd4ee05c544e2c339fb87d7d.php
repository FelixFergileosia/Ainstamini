<?php $__env->startSection('title','Profile'); ?>

<?php $__env->startSection('body'); ?>
    <main class="text-center d-flex justify-content-center mt-2">
        <div class="w-25 d-flex flex-column">
            <img class="mb-4 align-self-center rounded-circle"
                <?php if(Auth::user()->user_image != null): ?>
                    src="<?php echo e(asset('storage/images/'.Auth::user()->user_image)); ?>"
                <?php else: ?>
                    src="<?php echo e(asset('images/user_icon.png')); ?>"
                <?php endif; ?>
            alt="" style="width: 8vw">
            <div class="form-floating mb-3">
                <input name="email" type="email" class="form-control" value="<?php echo e(Auth::user()->username); ?>" placeholder="Email address" disabled>
                <label for="">Username</label>
            </div>
            <div class="form-floating mb-3">
                <input name="email" type="email" class="form-control" value="<?php echo e(Auth::user()->email); ?>" placeholder="Email address" disabled>
                <label for="">Email Address</label>
            </div>
            <div class="form-floating mb-3">
                <input name="phoneNumber" type="text" class="form-control" value="<?php echo e(Auth::user()->phone_number); ?>" placeholder="Phone number" disabled>
                <label for="">Phone Number</label>
            </div>
            <div class="form-floating mb-3">
                <input name="bio" type="text" class="form-control" value="<?php echo e(Auth::user()->bio); ?>" placeholder="Bio" disabled>
                <label for="">Bio</label>
            </div>
            <a  class="btn btn-primary" href="/edit-profile"> Edit Profile </a>
        </div>
    </main>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('base.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Programming\ainstamini_v1\resources\views/profile.blade.php ENDPATH**/ ?>